var totalRow = 0;
var cmd="";

function checkboxOnChange(x){
	var index = x.getAttribute("data-position");
	text = "deleteOne("+index + ");";
	if (x.checked) {
		if (!cmd.includes(text))
			cmd += text;
	}
	else{
		if (cmd.includes(text))
			cmd.replace(text/g, "");
		
	}
}
function deleteSelect(){
	eval(cmd);
}

function save() {
	// body... 
	var total;
	var fnameRec = $("[name='fname']");
	var lnameRec = $("[name='lname']");
	var factor = $("[name='factor']");
	var totalEach = $("[name='total']");
	var score = $("[name='score']");
	var date = $("[name='datepicker']");
	total = calculateTotal();
	var table = $("#tabOutput");
	rowdata = $("#tabOutput tr");
	for (var i = 1; i < rowdata.length; i++) {
		rowdata[i].remove();
	}

	for (var i = 0; i < fnameRec.length; i++) {
		var row = $('<tr class="outTab"></tr>')
		table.append(row);
		for (var k = 0; k < 7; k++) {
			var data = $('<td></td>')
			row.append(data);
			row.attr('align', 'center');
			switch (k) {
				case 0:{
					data.html(i+1);
					break;
				}
				case 1:{
					data.html(fnameRec[i].value);
					break;
				}
				case 2:{
					data.html(lnameRec[i].value);
					break;
				}
				case 3:{
					if (score[i].selectedIndex == 0) {
						data.html(" ");
					}
					else{
						data.html(score[i].selectedIndex - 1);
					}
					break;
				}
				case 4:{
					if (factor[i].value != "") {
						data.html(numberWithCommas(parseFloat(factor[i].value)));
					}
					else{
						data.html("");
					}
					break;
				}
				case 5:{
					data.html(date[i].value);
					break;
				}
				case 6:{
					data.html(totalEach[i].textContent);
					break;
				}
				default:
				break;
			}
		}
		if (isNaN(total)) {
			total = "";
		}
		$("#output").html('List of User\ ');
		$("#output").append(table);
		$("#output").append("total: " + numberWithCommas(total));

	}
}
function checkAll(x) {
	var allBox = $("[name='check']");
	for (var i = 0; i < allBox.length; i++) {
		allBox[i].checked = x.checked;
	}
}
function update(){
	var row = $("#table tr");
	for (var i = 1; i < row.length; i++) {
		var currentId = row[i].cells[1];
		currentId.innerHTML =i;
	}
}

function deleteOne (x) {
	$("#row" + x).remove();
	update();
	totalRow--;
}

function calculateScore(x) {
	var total = 0;
	var score = $("#score" + x).val();
	var factor = $("#factor" + x).val();
	if (factor < 0 || factor > 100) {
		alert("invalid He So");
		total = 0;
	}
	else{
		var total = score * factor;
	}
	if (isNaN(total)) {
		$("#total" + x).html("");
	}
	else{
		$("#total" + x).html(total);
	}

}

function calculateTotal(){
	var sum = 0;
	var total = $("[name='total']");
	for (var i = 0; i < total.length; i++) {
		console.log(total[i].textContent);
		console.log(total[i].textContent.replace(",", ""));
		sum += parseFloat(total[i].textContent.replace(/,/g, ''));
	}
	return sum;
}

function add(){
	var table = $("#table");
	var order = $("#table tr").length;
	table.append('"<tr id="row' + totalRow +'"></tr>"');
	var row = $("#row" + totalRow);
	var htmlOption ="";
	for (var i = 0; i < 9; i++) {
		var element;
		row.append('<td id="td' + totalRow + i +'"></td>');
		cell = $("#td" + totalRow + i)
		cell.attr("align", "center");
		switch (i) {
			case 0:{
				cell.append('<input type="checkbox" data-position="' + totalRow + '" onclick="checkboxOnChange(this)" align="center" name="check">');
				break;
			}
			case 1:{
				cell.append(order);
				break;
			}
			case 2:{
				cell.append('<input type="text"  name="fname">');
				break;
			}
			
			case 3:{
				cell.append('<input type="text"  name="lname">');
				break;
			}
			
			case 4:{
				select = $("<select></select>");
				select.attr({
					dir: 'rtl',
					onchange: "calculateScore(" + totalRow + ")",
					align: "center",
					name: "score",
					id: "score" + totalRow
				}); 
				select.append('<option value="null">Please Select</option>');
				for (var k = 1; k < 12; k++) {
					htmlOption += '<option value="' + (k - 1) +'">' + (k - 1) + '</option>';
				}
				select.append(htmlOption);
				cell.append(select);	
				break;
			}
			
			case 5:{
				cell.append('<input name="factor" type="number" min="0" max="100" id="factor' + totalRow + '" style="text-align: right" onchange="calculateScore('+ totalRow + ')" onkeyup="calculateScore('+ totalRow + ')">');
				break;
			}
			
			case 6:{
				cell.append('<input type="text" name="datepicker" id="datepicker' + totalRow + '">'); 
				break;
			}
			
			case 7:{
				cell.append('<div name="total" id="total' + totalRow + '" style="text-align: right"></div>');
				break;
			}
			
			case 8:{
				cell.append('<button class="delOne" onclick="deleteOne(' + totalRow + ')"></button>');
				break;
			}
			
			default:
				break;
		}
	}
	$('input[name="datepicker"]').datepicker();
	totalRow--;
}

function numberWithCommas(x) {
	return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}	
